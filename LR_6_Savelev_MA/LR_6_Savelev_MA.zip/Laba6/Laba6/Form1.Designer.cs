﻿namespace Laba6
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultField = new System.Windows.Forms.TextBox();
            this.resultLabel = new System.Windows.Forms.Label();
            this.addResultButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.catOfReasonLabel = new System.Windows.Forms.Label();
            this.reasonLabel = new System.Windows.Forms.Label();
            this.catOfReasonField = new System.Windows.Forms.TextBox();
            this.reasonField = new System.Windows.Forms.TextBox();
            this.addCatOfReasonButton = new System.Windows.Forms.Button();
            this.addReasonButton = new System.Windows.Forms.Button();
            this.newCatOfReasonButton = new System.Windows.Forms.Button();
            this.removeCatOfReasonButton = new System.Windows.Forms.Button();
            this.catOfReasonList = new System.Windows.Forms.ListBox();
            this.newResultButton = new System.Windows.Forms.Button();
            this.addReasonList = new System.Windows.Forms.ListBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.factorLabel = new System.Windows.Forms.Label();
            this.factorField = new System.Windows.Forms.TextBox();
            this.addFactorButton = new System.Windows.Forms.Button();
            this.addFactorList = new System.Windows.Forms.ListBox();
            this.removeFactorButton = new System.Windows.Forms.Button();
            this.loadDataButton = new System.Windows.Forms.Button();
            this.saveDataButton = new System.Windows.Forms.Button();
            this.showTreeButton = new System.Windows.Forms.Button();
            this.newReasonButton = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.removeReasonButton = new System.Windows.Forms.Button();
            this.reasonList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rootField = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addRootButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // resultField
            // 
            this.resultField.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resultField.ForeColor = System.Drawing.Color.DarkRed;
            this.resultField.Location = new System.Drawing.Point(14, 32);
            this.resultField.Name = "resultField";
            this.resultField.Size = new System.Drawing.Size(240, 22);
            this.resultField.TabIndex = 0;
            this.resultField.TextChanged += new System.EventHandler(this.troubleButtonEnabled);
            // 
            // resultLabel
            // 
            this.resultLabel.AutoSize = true;
            this.resultLabel.Location = new System.Drawing.Point(11, 12);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(245, 17);
            this.resultLabel.TabIndex = 1;
            this.resultLabel.Text = "Введите результат (корень дерева)";
            // 
            // addResultButton
            // 
            this.addResultButton.Enabled = false;
            this.addResultButton.Location = new System.Drawing.Point(14, 60);
            this.addResultButton.Name = "addResultButton";
            this.addResultButton.Size = new System.Drawing.Size(117, 54);
            this.addResultButton.TabIndex = 7;
            this.addResultButton.Text = "Добавить";
            this.addResultButton.UseVisualStyleBackColor = true;
            this.addResultButton.Click += new System.EventHandler(this.addResultButtonClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(408, 192);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1011, 250);
            this.dataGridView1.TabIndex = 5;
            // 
            // catOfReasonLabel
            // 
            this.catOfReasonLabel.AutoSize = true;
            this.catOfReasonLabel.Location = new System.Drawing.Point(329, 12);
            this.catOfReasonLabel.Name = "catOfReasonLabel";
            this.catOfReasonLabel.Size = new System.Drawing.Size(129, 17);
            this.catOfReasonLabel.TabIndex = 17;
            this.catOfReasonLabel.Text = "Категория причин";
            // 
            // reasonLabel
            // 
            this.reasonLabel.AutoSize = true;
            this.reasonLabel.Location = new System.Drawing.Point(677, 12);
            this.reasonLabel.Name = "reasonLabel";
            this.reasonLabel.Size = new System.Drawing.Size(66, 17);
            this.reasonLabel.TabIndex = 18;
            this.reasonLabel.Text = "Причина";
            // 
            // catOfReasonField
            // 
            this.catOfReasonField.Enabled = false;
            this.catOfReasonField.Location = new System.Drawing.Point(329, 32);
            this.catOfReasonField.Name = "catOfReasonField";
            this.catOfReasonField.Size = new System.Drawing.Size(282, 22);
            this.catOfReasonField.TabIndex = 19;
            this.catOfReasonField.TextChanged += new System.EventHandler(this.catOfReasonButtonEnabled);
            // 
            // reasonField
            // 
            this.reasonField.Enabled = false;
            this.reasonField.Location = new System.Drawing.Point(677, 32);
            this.reasonField.Name = "reasonField";
            this.reasonField.Size = new System.Drawing.Size(282, 22);
            this.reasonField.TabIndex = 20;
            this.reasonField.TextChanged += new System.EventHandler(this.reasonButtonEnabled);
            // 
            // addCatOfReasonButton
            // 
            this.addCatOfReasonButton.Enabled = false;
            this.addCatOfReasonButton.Location = new System.Drawing.Point(329, 60);
            this.addCatOfReasonButton.Name = "addCatOfReasonButton";
            this.addCatOfReasonButton.Size = new System.Drawing.Size(90, 54);
            this.addCatOfReasonButton.TabIndex = 21;
            this.addCatOfReasonButton.Text = "Добавить";
            this.addCatOfReasonButton.UseVisualStyleBackColor = true;
            this.addCatOfReasonButton.Click += new System.EventHandler(this.addCatOfReasonButtonClick);
            // 
            // addReasonButton
            // 
            this.addReasonButton.Enabled = false;
            this.addReasonButton.Location = new System.Drawing.Point(677, 60);
            this.addReasonButton.Name = "addReasonButton";
            this.addReasonButton.Size = new System.Drawing.Size(90, 54);
            this.addReasonButton.TabIndex = 22;
            this.addReasonButton.Text = "Добавить";
            this.addReasonButton.UseVisualStyleBackColor = true;
            this.addReasonButton.Click += new System.EventHandler(this.addReasonButtonClick);
            // 
            // newCatOfReasonButton
            // 
            this.newCatOfReasonButton.Enabled = false;
            this.newCatOfReasonButton.Location = new System.Drawing.Point(425, 60);
            this.newCatOfReasonButton.Name = "newCatOfReasonButton";
            this.newCatOfReasonButton.Size = new System.Drawing.Size(90, 54);
            this.newCatOfReasonButton.TabIndex = 23;
            this.newCatOfReasonButton.Text = "Новая";
            this.newCatOfReasonButton.UseVisualStyleBackColor = true;
            this.newCatOfReasonButton.Click += new System.EventHandler(this.newCatOfReasonButtonClick);
            // 
            // removeCatOfReasonButton
            // 
            this.removeCatOfReasonButton.Enabled = false;
            this.removeCatOfReasonButton.Location = new System.Drawing.Point(521, 60);
            this.removeCatOfReasonButton.Name = "removeCatOfReasonButton";
            this.removeCatOfReasonButton.Size = new System.Drawing.Size(90, 54);
            this.removeCatOfReasonButton.TabIndex = 24;
            this.removeCatOfReasonButton.Text = "Удалить";
            this.removeCatOfReasonButton.UseVisualStyleBackColor = true;
            this.removeCatOfReasonButton.Click += new System.EventHandler(this.removeCatOfReasonButtonClick);
            // 
            // catOfReasonList
            // 
            this.catOfReasonList.FormattingEnabled = true;
            this.catOfReasonList.ItemHeight = 16;
            this.catOfReasonList.Location = new System.Drawing.Point(329, 120);
            this.catOfReasonList.Name = "catOfReasonList";
            this.catOfReasonList.Size = new System.Drawing.Size(282, 20);
            this.catOfReasonList.TabIndex = 25;
            this.catOfReasonList.SelectedIndexChanged += new System.EventHandler(this.list_of_reason_SelectedIndexChanged);
            this.catOfReasonList.SelectedValueChanged += new System.EventHandler(this.list_of_reason_SelectedValueChanged);
            // 
            // newResultButton
            // 
            this.newResultButton.Location = new System.Drawing.Point(137, 60);
            this.newResultButton.Name = "newResultButton";
            this.newResultButton.Size = new System.Drawing.Size(117, 54);
            this.newResultButton.TabIndex = 28;
            this.newResultButton.Text = "Новый";
            this.newResultButton.UseVisualStyleBackColor = true;
            this.newResultButton.Click += new System.EventHandler(this.newResultButtonClick);
            // 
            // addReasonList
            // 
            this.addReasonList.FormattingEnabled = true;
            this.addReasonList.ItemHeight = 16;
            this.addReasonList.Location = new System.Drawing.Point(677, 120);
            this.addReasonList.Name = "addReasonList";
            this.addReasonList.Size = new System.Drawing.Size(282, 20);
            this.addReasonList.TabIndex = 29;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(408, 448);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1011, 250);
            this.dataGridView2.TabIndex = 34;
            // 
            // factorLabel
            // 
            this.factorLabel.AutoSize = true;
            this.factorLabel.Location = new System.Drawing.Point(1022, 12);
            this.factorLabel.Name = "factorLabel";
            this.factorLabel.Size = new System.Drawing.Size(59, 17);
            this.factorLabel.TabIndex = 35;
            this.factorLabel.Text = "Фактор";
            // 
            // factorField
            // 
            this.factorField.Enabled = false;
            this.factorField.Location = new System.Drawing.Point(1022, 32);
            this.factorField.Name = "factorField";
            this.factorField.Size = new System.Drawing.Size(242, 22);
            this.factorField.TabIndex = 36;
            this.factorField.TextChanged += new System.EventHandler(this.addFactorButtonEnabled);
            // 
            // addFactorButton
            // 
            this.addFactorButton.Enabled = false;
            this.addFactorButton.Location = new System.Drawing.Point(1022, 60);
            this.addFactorButton.Name = "addFactorButton";
            this.addFactorButton.Size = new System.Drawing.Size(117, 54);
            this.addFactorButton.TabIndex = 37;
            this.addFactorButton.Text = "Добавить";
            this.addFactorButton.UseVisualStyleBackColor = true;
            this.addFactorButton.Click += new System.EventHandler(this.addFactorButtonClick);
            // 
            // addFactorList
            // 
            this.addFactorList.FormattingEnabled = true;
            this.addFactorList.ItemHeight = 16;
            this.addFactorList.Location = new System.Drawing.Point(1147, 120);
            this.addFactorList.Name = "addFactorList";
            this.addFactorList.Size = new System.Drawing.Size(117, 20);
            this.addFactorList.TabIndex = 38;
            // 
            // removeFactorButton
            // 
            this.removeFactorButton.Enabled = false;
            this.removeFactorButton.Location = new System.Drawing.Point(1147, 60);
            this.removeFactorButton.Name = "removeFactorButton";
            this.removeFactorButton.Size = new System.Drawing.Size(117, 54);
            this.removeFactorButton.TabIndex = 39;
            this.removeFactorButton.Text = "Удалить";
            this.removeFactorButton.UseVisualStyleBackColor = true;
            this.removeFactorButton.Click += new System.EventHandler(this.removeFactorButtonClick);
            // 
            // loadDataButton
            // 
            this.loadDataButton.Location = new System.Drawing.Point(942, 704);
            this.loadDataButton.Name = "loadDataButton";
            this.loadDataButton.Size = new System.Drawing.Size(213, 45);
            this.loadDataButton.TabIndex = 42;
            this.loadDataButton.Text = "Загрузить";
            this.loadDataButton.UseVisualStyleBackColor = true;
            this.loadDataButton.Click += new System.EventHandler(this.loadDataButtonClick);
            // 
            // saveDataButton
            // 
            this.saveDataButton.Location = new System.Drawing.Point(696, 704);
            this.saveDataButton.Name = "saveDataButton";
            this.saveDataButton.Size = new System.Drawing.Size(240, 45);
            this.saveDataButton.TabIndex = 43;
            this.saveDataButton.Text = "Сохранить";
            this.saveDataButton.UseVisualStyleBackColor = true;
            this.saveDataButton.Click += new System.EventHandler(this.saveDataButtonClick);
            // 
            // showTreeButton
            // 
            this.showTreeButton.Enabled = false;
            this.showTreeButton.Location = new System.Drawing.Point(12, 704);
            this.showTreeButton.Name = "showTreeButton";
            this.showTreeButton.Size = new System.Drawing.Size(390, 45);
            this.showTreeButton.TabIndex = 44;
            this.showTreeButton.Text = "Вывести на экран";
            this.showTreeButton.UseVisualStyleBackColor = true;
            this.showTreeButton.Click += new System.EventHandler(this.showTreeButtonClick);
            // 
            // newReasonButton
            // 
            this.newReasonButton.Enabled = false;
            this.newReasonButton.Location = new System.Drawing.Point(773, 60);
            this.newReasonButton.Name = "newReasonButton";
            this.newReasonButton.Size = new System.Drawing.Size(90, 54);
            this.newReasonButton.TabIndex = 45;
            this.newReasonButton.Text = "Новая";
            this.newReasonButton.UseVisualStyleBackColor = true;
            this.newReasonButton.Click += new System.EventHandler(this.newReasonButtonClick);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(12, 192);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(390, 506);
            this.treeView1.TabIndex = 46;
            // 
            // removeReasonButton
            // 
            this.removeReasonButton.Enabled = false;
            this.removeReasonButton.Location = new System.Drawing.Point(869, 60);
            this.removeReasonButton.Name = "removeReasonButton";
            this.removeReasonButton.Size = new System.Drawing.Size(90, 54);
            this.removeReasonButton.TabIndex = 48;
            this.removeReasonButton.Text = "Удалить";
            this.removeReasonButton.UseVisualStyleBackColor = true;
            this.removeReasonButton.Click += new System.EventHandler(this.removeReasonButtonClick);
            // 
            // reasonList
            // 
            this.reasonList.FormattingEnabled = true;
            this.reasonList.ItemHeight = 16;
            this.reasonList.Location = new System.Drawing.Point(1022, 120);
            this.reasonList.Name = "reasonList";
            this.reasonList.Size = new System.Drawing.Size(117, 20);
            this.reasonList.TabIndex = 49;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(326, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 17);
            this.label1.TabIndex = 50;
            this.label1.Text = "Выбор категории";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(674, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(272, 17);
            this.label2.TabIndex = 51;
            this.label2.Text = "Выбор категории добавления\\удаления";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1019, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(346, 17);
            this.label3.TabIndex = 52;
            this.label3.Text = "Выбор категории и причины добавления/удаления";
            // 
            // rootField
            // 
            this.rootField.Enabled = false;
            this.rootField.Location = new System.Drawing.Point(277, 222);
            this.rootField.Name = "rootField";
            this.rootField.Size = new System.Drawing.Size(104, 22);
            this.rootField.TabIndex = 53;
            this.rootField.TextChanged += new System.EventHandler(this.addRootButtonEnabled);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(274, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 17);
            this.label4.TabIndex = 54;
            this.label4.Text = "Корень дерева";
            // 
            // addRootButton
            // 
            this.addRootButton.Enabled = false;
            this.addRootButton.Location = new System.Drawing.Point(277, 251);
            this.addRootButton.Name = "addRootButton";
            this.addRootButton.Size = new System.Drawing.Size(104, 23);
            this.addRootButton.TabIndex = 55;
            this.addRootButton.Text = "Добавить";
            this.addRootButton.UseVisualStyleBackColor = true;
            this.addRootButton.Click += new System.EventHandler(this.addRootButtonClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1431, 761);
            this.Controls.Add(this.addRootButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rootField);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.reasonList);
            this.Controls.Add(this.removeReasonButton);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.newReasonButton);
            this.Controls.Add(this.showTreeButton);
            this.Controls.Add(this.saveDataButton);
            this.Controls.Add(this.loadDataButton);
            this.Controls.Add(this.removeFactorButton);
            this.Controls.Add(this.addFactorList);
            this.Controls.Add(this.addFactorButton);
            this.Controls.Add(this.factorField);
            this.Controls.Add(this.factorLabel);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.addReasonList);
            this.Controls.Add(this.newResultButton);
            this.Controls.Add(this.catOfReasonList);
            this.Controls.Add(this.removeCatOfReasonButton);
            this.Controls.Add(this.newCatOfReasonButton);
            this.Controls.Add(this.addReasonButton);
            this.Controls.Add(this.addCatOfReasonButton);
            this.Controls.Add(this.reasonField);
            this.Controls.Add(this.catOfReasonField);
            this.Controls.Add(this.reasonLabel);
            this.Controls.Add(this.catOfReasonLabel);
            this.Controls.Add(this.addResultButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.resultField);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox resultField;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button addResultButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label catOfReasonLabel;
        private System.Windows.Forms.Label reasonLabel;
        private System.Windows.Forms.TextBox catOfReasonField;
        private System.Windows.Forms.TextBox reasonField;
        private System.Windows.Forms.Button addCatOfReasonButton;
        private System.Windows.Forms.Button addReasonButton;
        private System.Windows.Forms.Button newCatOfReasonButton;
        private System.Windows.Forms.Button removeCatOfReasonButton;
        private System.Windows.Forms.ListBox catOfReasonList;
        private System.Windows.Forms.Button newResultButton;
        private System.Windows.Forms.ListBox addReasonList;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label factorLabel;
        private System.Windows.Forms.TextBox factorField;
        private System.Windows.Forms.Button addFactorButton;
        private System.Windows.Forms.ListBox addFactorList;
        private System.Windows.Forms.Button removeFactorButton;
        private System.Windows.Forms.Button loadDataButton;
        private System.Windows.Forms.Button saveDataButton;
        private System.Windows.Forms.Button newReasonButton;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Button removeReasonButton;
        private System.Windows.Forms.ListBox reasonList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button showTreeButton;
        private System.Windows.Forms.TextBox rootField;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button addRootButton;
    }
}

